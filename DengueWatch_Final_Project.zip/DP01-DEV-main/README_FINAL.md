# Campus DengueWatch — Final Project

Django web application for ULAB campus mosquito hotspot reporting and spray-team workflow.

## Features
- Public campus map with report pins / hotspot heatmap; guest viewing requires no account.
- Student/teacher registration and login; authenticated users submit reports with category, notes, image, and map coordinates.
- Users can review their reports and edit active reports they submitted.
- Admin workflow: review active reports, dispatch them to an Authority/Spray Team account, monitor task status, and delete reports only after completion.
- Spray Team dashboard: open map directions to report coordinates, view submitted photo and details, update task to in-progress/completed, and add work notes.
- Campus boundary validation and daily submission limit.

## Run locally (Windows)
1. Install Python 3.11+.
2. Open terminal in this project folder.
3. Create and activate environment:
   ```bash
   py -m venv .venv
   .venv\\Scripts\\activate
   ```
4. Install dependencies:
   ```bash
   python -m pip install -r requirements.txt
   ```
5. Create database tables:
   ```bash
   python manage.py migrate
   ```
6. Create admin account:
   ```bash
   python manage.py createsuperuser
   ```
   Give this account the Admin role via Django Admin if needed (superuser role is set to ADMIN by manager).
7. Start server:
   ```bash
   python manage.py runserver
   ```
8. Open http://127.0.0.1:8000/

## Set up Spray Team
- Create a user through the registration page.
- In `/admin/`, edit that user and set **User Role = Authority**.
- Admin opens **Admin Workflow**, selects that team account for a report, and clicks Dispatch.

## Important
- Map tiles and Leaflet are loaded from their public CDN; internet is required for the map.
- Uploaded images are stored under `media/reports/` in development.
- Before production deployment, set `DJANGO_SECRET_KEY`, `DJANGO_DEBUG=False`, configure `ALLOWED_HOSTS`, HTTPS, and a production database/media server.
