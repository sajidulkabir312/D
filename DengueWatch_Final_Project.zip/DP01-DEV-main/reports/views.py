from django.conf import settings
from django.contrib import messages
from django.core.exceptions import ValidationError
from django.shortcuts import redirect
from django.urls import reverse_lazy
from django.utils import timezone
from django.views.generic import FormView, TemplateView, UpdateView
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.views import View
from django.shortcuts import get_object_or_404
from django.core.exceptions import PermissionDenied
from django.db import transaction

from accounts.permissions import ActorCapabilityMixin
from .forms import ReportForm
from .models import Report, ReportStatus, WorkTask, WorkTaskStatus
from .services import ReportService


class HeatmapView(ActorCapabilityMixin, TemplateView):
    """
    Public heatmap page. Renders real-time (latest on page load) active reports.
    Accessible to Guests and all authenticated users.
    """

    template_name = 'reports/heatmap.html'
    required_capability = 'view_heatmap'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        active_reports = Report.objects.active()

        reports_data = [
            {
                'id': r.id,
                'lat': r.latitude,
                'lng': r.longitude,
                'category': r.get_category_display(),
                'category_code': r.category,
                'note': r.note,
                'photo_url': r.photo.url if r.photo else None,
                'created_at': timezone.localtime(r.created_at).strftime('%b %d, %Y, %I:%M %p'),
            }
            for r in active_reports
        ]

        context['reports_data'] = reports_data
        context['campus_boundary'] = getattr(settings, 'CAMPUS_BOUNDARY', {})
        context['report_count'] = len(reports_data)
        return context


class ReportCreateView(ActorCapabilityMixin, FormView):
    """
    Mosquito activity reporting page.
    Requires 'submit_report' capability (Logged in RegisteredUser, Authority, or Admin).
    """

    template_name = 'reports/report_form.html'
    form_class = ReportForm
    success_url = reverse_lazy('heatmap')
    required_capability = 'submit_report'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['campus_boundary'] = getattr(settings, 'CAMPUS_BOUNDARY', {})
        return context

    def form_valid(self, form):
        try:
            ReportService.create_report(
                user=self.request.user,
                data=form.cleaned_data,
                files=self.request.FILES
            )
        except ValidationError as e:
            form.add_error(None, e)
            return self.form_invalid(form)

        messages.success(self.request, 'Report submitted successfully.')
        return redirect(self.success_url)


@method_decorator(login_required, name='dispatch')
class MyReportsView(TemplateView):
    template_name = 'reports/my_reports.html'
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['reports'] = Report.objects.filter(user=self.request.user).select_related('work_task')
        return context

@method_decorator(login_required, name='dispatch')
class ReportUpdateView(UpdateView):
    model = Report
    form_class = ReportForm
    template_name = 'reports/report_form.html'
    success_url = reverse_lazy('my_reports')
    def get_queryset(self):
        return Report.objects.filter(user=self.request.user, status=ReportStatus.VISIBLE)
    def form_valid(self, form):
        form.instance.user = self.request.user
        messages.success(self.request, 'Your report was updated.')
        return super().form_valid(form)

@method_decorator(login_required, name='dispatch')
class AdminWorkflowView(TemplateView):
    template_name = 'reports/admin_workflow.html'
    def dispatch(self, request, *args, **kwargs):
        if not request.user.has_capability('verify_reports'):
            raise PermissionDenied
        return super().dispatch(request, *args, **kwargs)
    def get_context_data(self, **kwargs):
        c=super().get_context_data(**kwargs)
        c['reports']=Report.objects.filter(status=ReportStatus.VISIBLE).select_related('user').prefetch_related('work_task')
        c['team_members']=get_user_model().objects.filter(role='AUTHORITY', is_active=True)
        c['tasks']=WorkTask.objects.select_related('report','assigned_to')
        return c

@method_decorator(login_required, name='dispatch')
class AssignTaskView(View):
    def post(self, request, report_id):
        if not request.user.has_capability('assign_task'):
            raise PermissionDenied
        report=get_object_or_404(Report, pk=report_id, status=ReportStatus.VISIBLE)
        team=get_object_or_404(get_user_model(), pk=request.POST.get('team_id'), role='AUTHORITY', is_active=True)
        WorkTask.objects.update_or_create(report=report, defaults={'assigned_to':team,'assigned_by':request.user,'status':WorkTaskStatus.ASSIGNED,'team_note':''})
        messages.success(request, 'Report sent to spray team.')
        return redirect('admin_workflow')

@method_decorator(login_required, name='dispatch')
class TeamDashboardView(TemplateView):
    template_name='reports/team_dashboard.html'
    def dispatch(self, request, *args, **kwargs):
        if not request.user.has_capability('view_assigned_areas'):
            raise PermissionDenied
        return super().dispatch(request,*args,**kwargs)
    def get_context_data(self, **kwargs):
        c=super().get_context_data(**kwargs)
        c['tasks']=WorkTask.objects.filter(assigned_to=self.request.user).select_related('report','report__user')
        return c

@method_decorator(login_required, name='dispatch')
class TaskUpdateView(View):
    def post(self, request, task_id):
        task=get_object_or_404(WorkTask,pk=task_id,assigned_to=request.user)
        status=request.POST.get('status')
        if status not in [WorkTaskStatus.IN_PROGRESS,WorkTaskStatus.COMPLETED]:
            raise PermissionDenied
        task.status=status
        task.team_note=request.POST.get('team_note','').strip()[:2000]
        task.save(update_fields=['status','team_note','updated_at'])
        if status == WorkTaskStatus.COMPLETED:
            task.report.status=ReportStatus.RESOLVED
            task.report.resolved_note=task.team_note or 'Spray/cleaning work completed.'
            task.report.save(update_fields=['status','resolved_note'])
        messages.success(request,'Task status updated.')
        return redirect('team_dashboard')

@method_decorator(login_required, name='dispatch')
class DeleteResolvedReportView(View):
    def post(self, request, report_id):
        if not request.user.has_capability('verify_reports'):
            raise PermissionDenied
        report=get_object_or_404(Report,pk=report_id,status=ReportStatus.RESOLVED)
        if report.photo:
            report.photo.delete(save=False)
        report.delete()
        messages.success(request,'Resolved report removed.')
        return redirect('admin_workflow')
