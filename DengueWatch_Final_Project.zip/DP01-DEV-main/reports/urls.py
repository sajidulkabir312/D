from django.urls import path
from .views import (HeatmapView, ReportCreateView, MyReportsView, ReportUpdateView, AdminWorkflowView, AssignTaskView, TeamDashboardView, TaskUpdateView, DeleteResolvedReportView)
urlpatterns = [
 path('', HeatmapView.as_view(), name='heatmap'),
 path('report/', ReportCreateView.as_view(), name='report_create'),
 path('my-reports/', MyReportsView.as_view(), name='my_reports'),
 path('report/<int:pk>/edit/', ReportUpdateView.as_view(), name='report_edit'),
 path('workflow/admin/', AdminWorkflowView.as_view(), name='admin_workflow'),
 path('workflow/assign/<int:report_id>/', AssignTaskView.as_view(), name='assign_task'),
 path('workflow/team/', TeamDashboardView.as_view(), name='team_dashboard'),
 path('workflow/task/<int:task_id>/', TaskUpdateView.as_view(), name='task_update'),
 path('workflow/report/<int:report_id>/delete/', DeleteResolvedReportView.as_view(), name='delete_resolved_report'),
]
